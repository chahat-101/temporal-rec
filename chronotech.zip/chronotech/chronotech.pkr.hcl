packer {
  required_plugins {
    virtualbox = {
      version = ">= 1.1.0"
      source  = "github.com/hashicorp/virtualbox"
    }
  }
}

variable "iso_path" {
  type        = string
  description = "Path to the Debian 13 netinst ISO on this computer"
}

variable "build_password" {
  type      = string
  default   = "builder"
  sensitive = true
}

variable "admin_password" {
  type        = string
  sensitive   = true
  description = "Password for the 'builder' admin account in the finished VMs (volunteers only)"
}

variable "keep_registered" {
  type        = bool
  default     = false
  description = "Leave the finished VM in this PC's VirtualBox (used by build.ps1 on the lab PCs)"
}

variable "skip_export" {
  type    = bool
  default = false
}

variable "ga_iso" {
  type    = string
  default = "/usr/lib/virtualbox/additions/VBoxGuestAdditions.iso"
}

# Settings shared by every station. Per-station settings live in the build block below.
source "virtualbox-iso" "debian" {
  iso_url              = var.iso_path
  iso_checksum         = "none"
  guest_os_type        = "Debian_64"
  headless             = true
  cpus                 = 2
  disk_size            = 25600
  hard_drive_interface = "sata"
  gfx_controller       = "vmsvga"
  gfx_vram_size        = 128
  guest_additions_mode = "disable"
  format               = "ova"
  keep_registered      = var.keep_registered
  skip_export          = var.skip_export

  boot_wait = "5s"
  boot_command = [
    "<wait><esc><wait>",
    "auto preseed/url=http://{{ .HTTPIP }}:{{ .HTTPPort }}/preseed.cfg<wait><enter>"
  ]

  communicator       = "ssh"
  ssh_username       = "builder"
  ssh_password       = var.build_password
  ssh_timeout        = "90m"
  ssh_host_port_min  = 5000
  ssh_host_port_max  = 6000
  shutdown_command   = "echo '${var.admin_password}' | sudo -S shutdown -P now"
  shutdown_timeout   = "10m"
}

build {
  source "source.virtualbox-iso.debian" {
    name               = "station1"
    vm_name            = "chronotech-station1"
    output_directory   = "output/station1"
    memory             = 4096
    gfx_accelerate_3d  = true
    http_content       = { "/preseed.cfg" = templatefile("preseed.pkrtpl.hcl", { hostname = "station1", tasks = "standard, xfce-desktop, ssh-server", password = var.build_password }) }
    vboxmanage_post    = [["modifyvm", "{{ .Name }}", "--nic1", "null"]]
  }

  source "source.virtualbox-iso.debian" {
    name               = "station2"
    vm_name            = "chronotech-station2"
    output_directory   = "output/station2"
    memory             = 4096
    gfx_accelerate_3d  = true
    http_content       = { "/preseed.cfg" = templatefile("preseed.pkrtpl.hcl", { hostname = "station2", tasks = "standard, xfce-desktop, ssh-server", password = var.build_password }) }
    vboxmanage_post    = [["modifyvm", "{{ .Name }}", "--nic1", "null"]]
  }

  source "source.virtualbox-iso.debian" {
    name               = "station3"
    vm_name            = "chronotech-station3"
    output_directory   = "output/station3"
    memory             = 4096
    gfx_accelerate_3d  = false
    http_content       = { "/preseed.cfg" = templatefile("preseed.pkrtpl.hcl", { hostname = "station3", tasks = "standard, xfce-desktop, ssh-server", password = var.build_password }) }
    vboxmanage_post    = [["modifyvm", "{{ .Name }}", "--nic1", "null"]]
  }

  source "source.virtualbox-iso.debian" {
    name               = "station4"
    vm_name            = "chronotech-station4"
    output_directory   = "output/station4"
    memory             = 5120
    gfx_accelerate_3d  = false
    http_content       = { "/preseed.cfg" = templatefile("preseed.pkrtpl.hcl", { hostname = "station4", tasks = "standard, mate-desktop, ssh-server", password = var.build_password }) }
    vboxmanage_post    = [["modifyvm", "{{ .Name }}", "--nic1", "null"]]
  }

  source "source.virtualbox-iso.debian" {
    name               = "station5"
    vm_name            = "chronotech-station5"
    output_directory   = "output/station5"
    memory             = 4096
    gfx_accelerate_3d  = false
    http_content       = { "/preseed.cfg" = templatefile("preseed.pkrtpl.hcl", { hostname = "station5", tasks = "standard, ssh-server", password = var.build_password }) }
    # Players SSH in from the host PC:  ssh -p 2222 agent@localhost
    vboxmanage_post    = [["modifyvm", "{{ .Name }}", "--natpf1", "player-ssh,tcp,127.0.0.1,2222,,22"]]
  }

  provisioner "shell" {
    inline = ["mkdir -p /tmp/ct/cache"]
  }

  # Ollama and the AI model, downloaded once by build.sh
  provisioner "file" {
    source      = "cache/"
    destination = "/tmp/ct/cache"
  }

  provisioner "file" {
    source      = "files/"
    destination = "/tmp/ct"
  }

  provisioner "file" {
    except      = ["virtualbox-iso.station5"]
    source      = var.ga_iso
    destination = "/tmp/ct/VBoxGuestAdditions.iso"
  }

  provisioner "shell" {
    execute_command  = "echo '${var.build_password}' | {{ .Vars }} sudo -S -E bash '{{ .Path }}'"
    environment_vars = ["STATION=${source.name}", "ADMIN_PASSWORD=${var.admin_password}"]
    script           = "provision.sh"
  }
}
