# Chronotech answer key (volunteers only)

Every station logs in as the player account `agent` (password `tva`, no admin rights).
Restore the `clean` snapshot after every team.
Admin account on every VM: `builder`, with the admin password chosen at build time.

## Station 1 - 1970s - TIME

1. `cc hello.c` fails: `hello.c:17: expected ';'`.
   Fix in ed: `ed hello.c` → `17` → `s/)$/);/` → `w` → `q`.
   Then `cc hello.c && ./a.out` prints the clue about mail.sh.
2. `sh mail.sh` fails: "cannot route 'agent#tva'".
   Fix in ed: `ed mail.sh` → `/agent#/s/#/@/` → `w` → `q`.
   Then `sh mail.sh` and `cat mbox`.
3. `ls -a` shows `.nexus` (58017600). `date -d @58017600` → 3 Nov 1971 (first Unix manual).
   `./vault` → type `1971-11-03` (or the full date output) → **TIME**.

## Station 2 - 1980s - LOOP

1. `./timeloop.sh` runs forever, counting backwards. Ctrl+C.
   Change `year=$((year - 1))` to `year=$((year + 1))` with nano. Run again → clue.
2. `cat brain.sh` shows the `tr` command. Run it on the scrambled file:
   `tr 'A-Za-z' 'N-ZA-Mn-za-m' < SCRAMBLED.TXT`
3. `./gnu.sh` → "Permission denied". `chmod +x gnu.sh`, then `./gnu.sh` → type `1983` → **LOOP**.
   (`bash gnu.sh` also works and is fine.)

## Station 3 - 1990s - BYTE

The page is `Desktop/TimeDoor/index.html`; edit it in Mousepad and reload Firefox.

1. Add `-->` at the end of the "TVA NOTE" comment line. Page appears.
2. Fix `setTimout` → `setTimeout`. The door appears after the countdown.
3. Change `year === 1995` → `year === "1995"`. Type 1995 → **BYTE**.

## Station 4 - 2000s - CORE

1. `python3 y2k_check.py` prints "19100". Change the year line to
   `year = str(1900 + years_since_1900)` → clue about Orkut's launch day.
2. `grep 2004-01-22 orkut_users.csv` → `variant_l0ki`, block data `sacred-timeline-2004`.
3. `python3 mine.py` gives up after 100 tries. Change `range(100)` to a big number
   (e.g. `range(1000000)`). Enter `sacred-timeline-2004` → nonce 1532 → **CORE**.

## Station 5 - 2010s - ZERO

Players open Windows Terminal on the host PC: `ssh -p 2222 agent@localhost` (password `tva`).
Hints: `ssh -p 2222 analyst@localhost` (password `analyst`).

1. `cd timeline`, `git branch -a` → `git checkout variant` → read CASEFILE.
2. `./build.sh` → secret.txt missing. `git log` shows "removed secret".
   `git show <that commit>` reveals `glorious-purpose`.
   `echo glorious-purpose > secret.txt`
3. `./build.sh` → left_pad.sh not found. `git log --oneline -- left_pad.sh` finds the
   delete commit. `git checkout <delete commit>^ -- left_pad.sh`
   (or copy it from `git show <older commit>:left_pad.sh`). `./build.sh` → **ZERO**.
