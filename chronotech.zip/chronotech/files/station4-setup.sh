#!/bin/bash
# Chronotech - Station 4 (2000s: Y2K, Orkut and Bitcoin) - code word CORE
# Run inside the Station 4 VM (Debian + MATE):   sudo bash station4-setup.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run this with sudo."; exit 1; }

AGENT=agent
H=/home/$AGENT

if [ "${SKIP_APT:-0}" != 1 ]; then
  apt-get update
  apt-get install -y python3 dconf-cli mate-terminal pluma firefox-esr
fi

id "$AGENT" >/dev/null 2>&1 || useradd -m -s /bin/bash "$AGENT"
echo "$AGENT:tva" | chpasswd

# ---------- Easy: the "19100" Y2K bug ----------
cat > "$H/y2k_check.py" <<'EOF'
#!/usr/bin/env python3
# y2k_check.py - written in 1998. "This will be fine until at least 2000."
# Like the clock in C (struct tm), this program counts years since 1900.
import hashlib

years_since_1900 = 100          # the clock says: 1 January 2000

year = "19" + str(years_since_1900)
print("Today's date: 1 January", year)

CLUE = bytes.fromhex(
    "7d425b4546105f40575e5554125f5e100002107a535e4551404910020200041e127f5e55125d555d5055"
    "4210585f595e5754105f5c10445853441046574249105651490a12445855124651425b515e441c1076595c"
    "5410445a555d105b5e105f405b45446d45435540431e534146")
clue = bytes(b ^ ord(year[i % len(year)]) for i, b in enumerate(CLUE))

if hashlib.sha256(clue).hexdigest().startswith("010d556bf708"):
    print(clue.decode())
else:
    print("ERROR: the clue is corrupted. Nobody can read it in the year", year)
EOF

# ---------- Medium: 5,000 Orkut members, one joined on launch day ----------
python3 - "$H/orkut_users.csv" <<'EOF'
import csv, datetime, random, sys
random.seed(2004)
first = ["Aarav","Priya","Rohan","Sneha","Vikram","Ananya","Rahul","Pooja","Arjun","Neha","Karan","Divya",
         "Siddharth","Meera","Aditya","Kavya","Nikhil","Isha","Varun","Riya","Manish","Tanvi","Gaurav","Shreya"]
cities = ["Pune","Mumbai","Delhi","Bengaluru","Chennai","Kolkata","Hyderabad","Ahmedabad","Jaipur","Lucknow",
          "Indore","Bhopal","Nagpur","Kochi","Chandigarh","Goa","Surat","Patna","Guwahati","Mysuru"]
scraps = ["happy bday yaar!!","plz add me 2 ur friends","testimonial pending :P","nice pics","miss u guys",
          "join my community","wat r u doing","scrap me back","lol","good morning frndz"]
start, end = datetime.date(2004, 1, 23), datetime.date(2014, 9, 30)
rows = []
for i in range(4999):
    d = start + datetime.timedelta(days=random.randrange((end - start).days + 1))
    name = random.choice(first)
    rows.append([f"{name.lower()}_{random.randrange(10, 9999)}", name, random.choice(cities),
                 d.isoformat(), random.randrange(0, 500), random.choice(scraps)])
rows.insert(3187, ["variant_l0ki", "Variant", "Unknown", "2004-01-22", 1,
                   "my block data is: sacred-timeline-2004"])
with open(sys.argv[1], "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["username", "name", "city", "joined", "fans", "last_scrap"])
    w.writerows(rows)
EOF

# ---------- Stretch: a lazy Bitcoin-style miner ----------
cat > "$H/mine.py" <<'EOF'
#!/usr/bin/env python3
# mine.py - proof of work, the way Bitcoin did it in 2009.
# Find a nonce so that sha256(block data + nonce) starts with "0000".
import hashlib

data = input("Block data: ").strip()
LOCKED = bytes.fromhex("f182db92")   # the code word, locked to the winning hash

for nonce in range(100):
    h = hashlib.sha256(f"{data}{nonce}".encode()).hexdigest()
    if h.startswith("0000"):
        key = bytes.fromhex(h)[-4:]
        word = bytes(a ^ b for a, b in zip(LOCKED, key)).decode("latin-1")
        print(f"Block mined! nonce={nonce}")
        print(f"hash={h}")
        if word.isalpha() and word.isupper():
            print("Branch pruned. Code word:", word)
        else:
            print("This block belongs to another timeline. Check your block data.")
        break
else:
    print("Gave up after 100 tries. No block found.")
EOF

# ---------- the case file, as a 2004-style social profile page ----------
cat > "$H/orkut.html" <<'EOF'
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>TVA Agent - Profile</title>
<style>
 body{margin:0;background:#d4dded;font-family:Verdana,Arial,sans-serif;font-size:12px;color:#000}
 .top{background:#bfd0ea;border-bottom:3px solid #e8177d;padding:8px 16px;font-size:22px;color:#e8177d;font-weight:bold}
 .top small{font-size:11px;color:#1a3a7a;font-weight:normal;margin-left:12px}
 .wrap{display:flex;gap:12px;padding:12px;max-width:900px}
 .box{background:#fff;border:1px solid #a5b6d6;padding:10px}
 .left{width:180px}.pic{width:160px;height:160px;background:#e5ecf9;display:flex;align-items:center;justify-content:center;font-size:56px;color:#1a3a7a}
 h2{color:#1a3a7a;font-size:14px;border-bottom:1px solid #c9d6ee;padding-bottom:4px}
 .scrap{border-bottom:1px dotted #a5b6d6;padding:8px 0}.from{color:#e8177d;font-weight:bold}
 code{background:#eef;padding:1px 4px}
</style></head><body>
<div class="top">scrapbook <small>a tribute to the social web of 2004 · Home | Scrapbook | Friends | Communities</small></div>
<div class="wrap">
 <div class="box left"><div class="pic">TVA</div><b>Agent of the TVA</b><br>fans: 0<br>status: on a case</div>
 <div class="box" style="flex:1">
  <h2>Scrapbook (3)</h2>
  <div class="scrap"><span class="from">TVA Command:</span> Nexus event detected in the 2000s, agent. A variant broke three programs in your home folder. Open a terminal and start with <code>python3 y2k_check.py</code></div>
  <div class="scrap"><span class="from">TVA Command:</span> The year 2000 broke real websites too. Some showed the date as "1 January 19100".</div>
  <div class="scrap"><span class="from">variant_l0ki:</span> u will never find me among 5000 ppl lol. plz dont add me :P</div>
 </div>
</div></body></html>
EOF

cat > "$H/CASEFILE.txt" <<'EOF'
TVA CASE FILE 2004-0122
Nexus event: the 2000s. Y2K, the social web and the first cryptocurrency.
Start here:   python3 y2k_check.py
EOF

# ---------- 2006-style brown and orange desktop (MATE) ----------
mkdir -p /etc/dconf/profile /etc/dconf/db/local.d
printf 'user-db:user\nsystem-db:local\n' > /etc/dconf/profile/user
cat > /etc/dconf/db/local.d/00-chronotech <<'EOF'
[org/mate/desktop/background]
picture-options='none'
color-shading-type='vertical-gradient'
primary-color='#5a3a22'
secondary-color='#d9822b'
EOF
command -v dconf >/dev/null && dconf update || true

# ---------- autostart: profile page, a terminal, the TVA Analyst ----------
mkdir -p "$H/.config/autostart"
cat > "$H/.config/autostart/profile.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Profile page
Exec=firefox-esr $H/orkut.html
EOF
cat > "$H/.config/autostart/terminal.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=Terminal
Exec=mate-terminal --working-directory=/home/agent
EOF
cat > "$H/.config/autostart/analyst.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=TVA Analyst
Exec=mate-terminal --title "TVA Analyst" -e /usr/local/bin/tva-analyst
EOF

chown -R "$AGENT:$AGENT" "$H"
chmod 644 "$H/y2k_check.py" "$H/mine.py" "$H/orkut_users.csv" "$H/orkut.html" "$H/CASEFILE.txt"
echo
echo "Station 4 ready. Player account: $AGENT (password: tva)."
