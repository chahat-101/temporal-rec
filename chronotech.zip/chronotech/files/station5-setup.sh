#!/bin/bash
# Chronotech - Station 5 (2010s: GitHub and the cloud) - code word ZERO
# Run inside the Station 5 VM (headless Debian):   sudo bash station5-setup.sh
# Players connect from the host PC through a NAT port forward:  ssh -p 2222 agent@localhost
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run this with sudo."; exit 1; }

AGENT=agent
H=/home/$AGENT
R=$H/timeline

if [ "${SKIP_APT:-0}" != 1 ]; then
  apt-get update
  apt-get install -y git openssl openssh-server
fi

id "$AGENT" >/dev/null 2>&1 || useradd -m -s /bin/bash "$AGENT"
echo "$AGENT:tva" | chpasswd

# Second login for hints: ssh -p 2222 analyst@localhost opens the TVA Analyst directly
id analyst >/dev/null 2>&1 || useradd -m -s /usr/local/bin/tva-analyst analyst
echo "analyst:analyst" | chpasswd
grep -qx /usr/local/bin/tva-analyst /etc/shells || echo /usr/local/bin/tva-analyst >> /etc/shells

# ---------- build the repository, with a history dated across the 2010s ----------
SECRET="glorious-purpose"
left_pad() { local s="$1" n="$2" c="${3:- }"; while [ ${#s} -lt "$n" ]; do s="$c$s"; done; printf '%s' "$s"; }
BLOB=$(printf 'WORD:ZERO' | openssl enc -aes-256-cbc -pbkdf2 -salt -a -A -pass "pass:$(left_pad "$SECRET" 24 0)")

rm -rf "$R"; mkdir -p "$R"; cd "$R"
git init -q -b main
c() {  # c <date> <author> <message>
  GIT_AUTHOR_DATE="$1" GIT_COMMITTER_DATE="$1" \
  git -c user.name="$2" -c user.email="$(echo "$2" | tr 'A-Z ' 'a-z.')@tva.example" commit -q -m "$3"
}

cat > README.md <<'EOF'
# timeline

The Sacred Timeline build system. Run `./build.sh` to build the timeline.
EOF
git add README.md; c "2012-04-10T10:00:00" "TVA Dev" "initial timeline"

cat > left_pad.sh <<'EOF'
# left_pad.sh - pad a string on the left until it is N characters long.
# Usage: left_pad <string> <length> [pad character]
left_pad() {
    local s="$1" n="$2" c="${3:- }"
    while [ ${#s} -lt "$n" ]; do s="$c$s"; done
    printf '%s' "$s"
}
EOF
cat > build.sh <<EOF
#!/bin/bash
# build.sh - builds the Sacred Timeline.
cd "\$(dirname "\$0")"

if [ ! -f secret.txt ]; then
    echo "build failed: secret.txt (the build key) is missing"
    exit 1
fi
if [ ! -f left_pad.sh ]; then
    echo "npm ERR! 404 Not Found: left_pad.sh"
    echo "build failed: a dependency has disappeared"
    exit 1
fi
source ./left_pad.sh

KEY=\$(left_pad "\$(cat secret.txt)" 24 0)
plain=\$(printf '%s\n' '$BLOB' | openssl enc -d -aes-256-cbc -pbkdf2 -a -A -pass "pass:\$KEY" 2>/dev/null) || plain=""
case "\$plain" in
    WORD:*) echo "Build succeeded. Branch pruned. Code word: \${plain#WORD:}" ;;
    *)      echo "build failed: wrong build key in secret.txt"; exit 1 ;;
esac
EOF
chmod 755 build.sh
git add left_pad.sh build.sh; c "2013-06-02T15:30:00" "TVA Dev" "add build system"

echo "$SECRET" > secret.txt
git add secret.txt; c "2014-09-15T23:41:00" "TVA Dev" "add build key"

git rm -q secret.txt
echo "secret.txt" > .gitignore
git add .gitignore; c "2014-09-16T09:02:00" "TVA Dev" "removed secret"

echo "Build: ./build.sh" >> README.md
git add README.md; c "2015-11-20T12:00:00" "TVA Dev" "update readme"

git rm -q left_pad.sh
c "2016-03-22T18:00:00" "variant" "remove left-pad, who needs an 11-line package anyway"

git checkout -q -b variant
cat > CASEFILE <<'EOF'
=====================================================
  TIME VARIANCE AUTHORITY  -  CASE FILE 2016-0322
=====================================================
NEXUS EVENT: the 2010s. GitHub, the cloud, and the day
an 11-line package called left-pad broke the internet.

The variant broke this repository's build. Try it:  ./build.sh

Nothing committed to git is ever truly gone.
  git log      shows the history
  git show     shows what a commit changed

Fix the build and it will print the code word.
EOF
git add CASEFILE; c "2016-03-23T08:00:00" "variant" "you will never find what I deleted"
git checkout -q main
git config --global --add safe.directory "$R" 2>/dev/null || true
cd /

# ---------- SSH welcome message ----------
cat > /etc/motd <<'EOF'

  =========================================================
     TIME VARIANCE AUTHORITY  -  REMOTE ARCHIVE  (2010s)
  =========================================================
  A nexus event was traced to the repository in ~/timeline.
  The variant works on a branch of its own.

EOF

chown -R "$AGENT:$AGENT" "$H"

echo
echo "Station 5 ready. Players: ssh -p 2222 agent@localhost   (password tva)"
echo "Hints:          ssh -p 2222 analyst@localhost (password analyst)"
