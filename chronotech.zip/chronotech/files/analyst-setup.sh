#!/bin/bash
# Chronotech - installs the TVA Analyst (hint-only AI) inside any station VM.
# Needs internet. Keep Modelfile and tva-analyst in the same folder as this script.
# Run inside the VM:   sudo bash analyst-setup.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run this with sudo."; exit 1; }
cd "$(dirname "$0")"
[ -f Modelfile ] && [ -f tva-analyst ] || { echo "Modelfile and tva-analyst must be next to this script."; exit 1; }

apt-get update
apt-get install -y curl python3 zstd
# Install Ollama: from the build cache if present, otherwise from the internet
TARBALL=$(ls cache/ollama-linux-amd64.* 2>/dev/null | head -1 || true)
if ! command -v ollama >/dev/null && [ -n "$TARBALL" ]; then
  # CPU only: skip the GPU libraries, the VMs have no GPU
  case "$TARBALL" in
    *.zst) tar --zstd -xf "$TARBALL" -C /usr/local --wildcards --exclude='*cuda_v*' --exclude='*rocm*' ;;
    *)     tar -xzf "$TARBALL" -C /usr/local --wildcards --exclude='*cuda_v*' --exclude='*rocm*' ;;
  esac
  id ollama >/dev/null 2>&1 || useradd -r -s /bin/false -U -m -d /usr/share/ollama ollama
  cat > /etc/systemd/system/ollama.service <<'UNIT'
[Unit]
Description=Ollama Service
After=network-online.target

[Service]
ExecStart=/usr/local/bin/ollama serve
User=ollama
Group=ollama
Restart=always
RestartSec=3

[Install]
WantedBy=default.target
UNIT
  systemctl daemon-reload
fi
command -v ollama >/dev/null || curl -fsSL https://ollama.com/install.sh | sh

# The model: copy from the build cache if present, otherwise download it
if [ -d cache/models/manifests ]; then
  systemctl stop ollama 2>/dev/null || true
  mkdir -p /usr/share/ollama/.ollama/models
  cp -r cache/models/. /usr/share/ollama/.ollama/models/
  chown -R ollama:ollama /usr/share/ollama/.ollama
  systemctl enable --now ollama
  sleep 4
else
  systemctl enable --now ollama
  sleep 4
  ollama pull llama3.2:3b
fi
ollama create tva-analyst -f Modelfile
install -m 755 tva-analyst /usr/local/bin/tva-analyst
grep -qx /usr/local/bin/tva-analyst /etc/shells || echo /usr/local/bin/tva-analyst >> /etc/shells

# Players can use the Analyst but cannot start their own ollama chat (which allows /set system)
OLLAMA_BIN=$(command -v ollama)
chown root:ollama "$OLLAMA_BIN"
chmod 750 "$OLLAMA_BIN"

echo
echo "TVA Analyst installed. Test it with:  tva-analyst"
