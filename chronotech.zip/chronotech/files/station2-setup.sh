#!/bin/bash
# Chronotech - Station 2 (1980s: GNU, floppies and the first PC virus) - code word LOOP
# Run inside the Station 2 VM:   sudo bash station2-setup.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run this with sudo."; exit 1; }

AGENT=agent
H=/home/$AGENT

if [ "${SKIP_APT:-0}" != 1 ]; then
  apt-get update
  apt-get install -y openssl nano xfce4-terminal
  apt-get install -y cool-retro-term || echo "WARNING: cool-retro-term not installed - use xterm with amber colours instead."
  apt-get purge -y mousepad || true
fi

id "$AGENT" >/dev/null 2>&1 || useradd -m -s /bin/bash "$AGENT"
echo "$AGENT:tva" | chpasswd

# bash 1.0 came out in 1989
grep -q 'CHRONOTECH' "$H/.bashrc" 2>/dev/null || cat >> "$H/.bashrc" <<'EOF'
# CHRONOTECH
PS1='bash-1.0$ '
cd ~
EOF

cat > "$H/CASEFILE" <<'EOF'
=====================================================
  TIME VARIANCE AUTHORITY  -  CASE FILE 1986-0119
=====================================================
NEXUS EVENT: the 1980s - home computers, floppy disks,
the GNU project and the first PC virus.

A variant is trapped in a time loop inside timeloop.sh.
Run it:   ./timeloop.sh
(If it never stops, press Ctrl+C. Then find out why.)

Break the loop and follow the trail to the code word.
EOF

# ---------- Easy: the year runs backwards forever ----------
cat > "$H/timeloop.sh" <<'EOF'
#!/bin/bash
# timeloop.sh - walks the variant through the 1980s, one year at a time.

year=1980
while [ $year -le 1989 ]; do
    echo "The year is $year... the variant is still here."
    sleep 0.3
    year=$((year - 1))
done

echo "TG9vcCBicm9rZW4hIE5leHQ6IGJyYWluLnNoIHNjcmFtYmxlZCB5b3VyIG9yZGVycyBpbnRvIFNDUkFNQkxFRC5UWFQuIFJlYWQgYnJhaW4uc2ggdG8gc2VlIGhvdyBpdCBkaWQgaXQu" | base64 -d
echo
EOF

# ---------- Medium: ROT13-scrambled orders ----------
cat > "$H/brain.sh" <<'EOF'
#!/bin/bash
# brain.sh - written by the variant, 1986.
# A tribute to Brain, the first IBM PC virus (Lahore, 1986).
# Scrambles the TVA's orders so no agent can read them.

tr 'A-Za-z' 'N-ZA-Mn-za-m' < orders.txt > SCRAMBLED.TXT
rm orders.txt

echo "Orders scrambled. Good luck, TVA."
EOF
printf '%s\n' \
  "TVA ORDERS - 1986" \
  "" \
  "Agent, you unscrambled ROT13, the letter-rotation trick from early-80s Usenet." \
  "" \
  "The variant locked the last file. gnu.sh will not run until you give it" \
  "permission to run. Once it runs, it asks for the year the GNU project was" \
  "announced. The announcement is in your home folder." \
  | tr 'A-Za-z' 'N-ZA-Mn-za-m' > "$H/SCRAMBLED.TXT"

# ---------- Stretch: gnu.sh without execute permission ----------
cat > "$H/GNU-ANNOUNCEMENT.txt" <<'EOF'
net.unix-wizards  -  27 September 1983

Richard Stallman of the MIT AI Lab posted that he would write a complete
Unix-compatible operating system called GNU ("GNU's Not Unix") and give it
away free to everyone who could use it.

Today, most Linux systems still run GNU tools: bash, ls, cat, tr and more.
EOF
BLOB=$(printf 'WORD:LOOP' | openssl enc -aes-256-cbc -pbkdf2 -salt -a -A -pass pass:1983)
cat > "$H/gnu.sh" <<EOF
#!/bin/bash
# gnu.sh - GNU's Not Unix
read -r -p "In what year was the GNU project announced? " year
plain=\$(printf '%s\n' '$BLOB' | openssl enc -d -aes-256-cbc -pbkdf2 -a -A -pass "pass:\$year" 2>/dev/null) || plain=""
case "\$plain" in
    WORD:*) echo "Branch pruned. Code word: \${plain#WORD:}" ;;
    *)      echo "That is not when it happened. Read the announcement again." ; exit 1 ;;
esac
EOF

# ---------- autostart: amber CRT terminal + the TVA Analyst ----------
mkdir -p "$H/.config/autostart"
cat > "$H/.config/autostart/era.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=1980s Terminal
Exec=cool-retro-term --fullscreen --profile "Default Amber"
EOF
cat > "$H/.config/autostart/analyst.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=TVA Analyst
Exec=xfce4-terminal --title "TVA Analyst" -x /usr/local/bin/tva-analyst
EOF

chown -R "$AGENT:$AGENT" "$H"
chmod 755 "$H/timeloop.sh" "$H/brain.sh"
chmod 644 "$H/gnu.sh" "$H/SCRAMBLED.TXT" "$H/GNU-ANNOUNCEMENT.txt" "$H/CASEFILE"
echo
echo "Station 2 ready. Player account: $AGENT (password: tva)."
