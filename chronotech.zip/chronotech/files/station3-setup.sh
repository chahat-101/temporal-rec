#!/bin/bash
# Chronotech - Station 3 (1990s: the web goes public) - code word BYTE
# Run inside the Station 3 VM (Debian + Xfce):   sudo bash station3-setup.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run this with sudo."; exit 1; }

AGENT=agent
H=/home/$AGENT

if [ "${SKIP_APT:-0}" != 1 ]; then
  apt-get update
  apt-get install -y git firefox-esr mousepad xfce4-terminal x11-xserver-utils xfconf
fi

id "$AGENT" >/dev/null 2>&1 || useradd -m -s /bin/bash "$AGENT"
echo "$AGENT:tva" | chpasswd

# ---------- Chicago95 (Windows 95 look) ----------
if [ "${SKIP_APT:-0}" != 1 ]; then
  TMP=$(mktemp -d)
  if git clone --depth 1 https://github.com/grassmunk/Chicago95.git "$TMP/c95"; then
    [ -d "$TMP/c95/Theme/Chicago95" ] && cp -r "$TMP/c95/Theme/Chicago95" /usr/share/themes/
    [ -d "$TMP/c95/Icons/Chicago95" ] && cp -r "$TMP/c95/Icons/Chicago95" /usr/share/icons/
    [ -d /usr/share/themes/Chicago95 ] || echo "WARNING: Chicago95 theme folder not found - install it by hand."
  else
    echo "WARNING: could not download Chicago95 - install it by hand."
  fi
  rm -rf "$TMP"
fi

X=$H/.config/xfce4/xfconf/xfce-perchannel-xml
mkdir -p "$X"
cat > "$X/xsettings.xml" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xsettings" version="1.0">
  <property name="Net" type="empty">
    <property name="ThemeName" type="string" value="Chicago95"/>
    <property name="IconThemeName" type="string" value="Chicago95"/>
  </property>
</channel>
EOF
cat > "$X/xfwm4.xml" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfwm4" version="1.0">
  <property name="general" type="empty">
    <property name="theme" type="string" value="Chicago95"/>
  </property>
</channel>
EOF

# Teal desktop and 800x600, applied at each login
cat > /usr/local/bin/era3-look <<'EOF'
#!/bin/sh
sleep 4
xrandr -s 800x600 2>/dev/null || true
for base in $(xfconf-query -c xfce4-desktop -l 2>/dev/null | grep 'last-image$' | sed 's#/last-image$##'); do
  xfconf-query -c xfce4-desktop -p "$base/image-style" -n -t int -s 0 2>/dev/null || xfconf-query -c xfce4-desktop -p "$base/image-style" -s 0
  xfconf-query -c xfce4-desktop -p "$base/color-style" -n -t int -s 0 2>/dev/null || xfconf-query -c xfce4-desktop -p "$base/color-style" -s 0
  xfconf-query -c xfce4-desktop -p "$base/rgba1" -n -t double -s 0 -t double -s 0.5 -t double -s 0.5 -t double -s 1 2>/dev/null || true
done
EOF
chmod 755 /usr/local/bin/era3-look

# ---------- the challenge ----------
mkdir -p "$H/Desktop/TimeDoor"
cat > "$H/Desktop/TimeDoor/index.html" <<'EOF'
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>~*~ THE TIME DOOR ~*~</title>
<style>
  body {
    background: #000033;
    color: #00ff66;
    font-family: "Times New Roman", serif;
  }
  h1 { color: #ffff00; font-family: "Comic Sans MS", cursive; }
  a { color: #00ffff; }
  .blink { animation: blink 1s steps(1) infinite; color: #ff3333; font-weight: bold; }
  @keyframes blink { 50% { visibility: hidden; } }
  #door {
    display: none;
    width: 320px;
    margin: 20px auto;
    padding: 12px;
    background: #c0c0c0;
    color: #000000;
    border: 4px outset #ffffff;
    font-family: "MS Sans Serif", Arial, sans-serif;
  }
  #door .titlebar {
    background: #000080;
    color: #ffffff;
    padding: 2px 6px;
    margin: -12px -12px 10px -12px;
    text-align: left;
    font-weight: bold;
  }
  table { border-color: #00ff66; }
  td { padding: 4px 8px; }
</style>
</head>
<body>
<!-- TVA NOTE: old visitor counter code, delete before launch
<center>
  <h1>~*~ Welcome to THE TIME DOOR ~*~</h1>
  <marquee scrollamount="4">You are visitor #000451 since 1995!! Sign my guestbook!!</marquee>
  <p class="blink">UNDER CONSTRUCTION</p>
  <p>The door opens in <span id="count">10</span> seconds...</p>

  <div id="door">
    <div class="titlebar">TimeDoor.exe</div>
    Enter the year:<br><br>
    <input id="pw" size="10">
    <button onclick="checkDoor()">Open</button>
    <p id="result"></p>
  </div>

  <h3>~ Guestbook ~</h3>
  <table border="1">
    <tr><td>Agent M.</td><td>Signed this the year Windows 95 came out. Best year ever!!</td></tr>
    <tr><td>xX_variant_Xx</td><td>u will never get thru the door lol</td></tr>
    <tr><td>webmaster</td><td>Best viewed in Netscape Navigator at 800x600</td></tr>
  </table>

  <p><a href="#">[ Back to my homepage ]</a></p>
</center>

<script>
  var t = 10;

  function tick() {
    t = t - 1;
    document.getElementById("count").innerText = t;
    if (t > 0) {
      setTimout(tick, 1000);
    } else {
      document.getElementById("door").style.display = "block";
    }
  }

  setTimeout(tick, 1000);

  function checkDoor() {
    var year = document.getElementById("pw").value;
    if (year === 1995) {
      var w = [66, 89, 84, 69];
      var word = "";
      for (var i = 0; i < w.length; i++) {
        word += String.fromCharCode(w[i]);
      }
      document.getElementById("result").innerText = "Branch pruned. Code word: " + word;
    } else {
      document.getElementById("result").innerText = "ACCESS DENIED. The timeline does not recognise you.";
    }
  }
</script>
</body>
</html>
EOF
cat > "$H/Desktop/CASEFILE.txt" <<'EOF'
=====================================================
  TIME VARIANCE AUTHORITY  -  CASE FILE 1995-0451
=====================================================

NEXUS EVENT DETECTED: 1995, The World Wide Web

A variant has sabotaged "The Time Door", a personal
homepage on the early web. The page is broken and the
door will not open. While it stays shut, the Sacred
Timeline keeps branching.

YOUR ORDERS
  1. The Time Door is open in the web browser.
  2. Find out why the page is broken and fix it.
     (The page's files are in the TimeDoor folder
      on the desktop. Edit them with Mousepad.)
  3. Get through the door and recover the code word.

Prune the branch. Restore the timeline.

                         -- TVA, Department of Web Affairs
EOF

mkdir -p "$H/.config/autostart"
cat > "$H/.config/autostart/look.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=1990s look
Exec=/usr/local/bin/era3-look
EOF
cat > "$H/.config/autostart/timedoor.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=The Time Door
Exec=sh -c "sleep 6; firefox-esr /home/agent/Desktop/TimeDoor/index.html"
EOF
cat > "$H/.config/autostart/analyst.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=TVA Analyst
Exec=xfce4-terminal --title "TVA Analyst" -x /usr/local/bin/tva-analyst
EOF

chown -R "$AGENT:$AGENT" "$H"
echo
echo "Station 3 ready. Player account: $AGENT (password: tva)."
