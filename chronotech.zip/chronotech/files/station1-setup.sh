#!/bin/bash
# Chronotech - Station 1 (1970s Bell Labs) - code word TIME
# Run inside the Station 1 VM:   sudo bash station1-setup.sh
# Creates the unprivileged player account "agent" and all challenge files.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run this with sudo."; exit 1; }

AGENT=agent
H=/home/$AGENT

if [ "${SKIP_APT:-0}" != 1 ]; then
  apt-get update
  apt-get install -y gcc libc6-dev ed xfce4-terminal
  apt-get install -y cool-retro-term || echo "WARNING: cool-retro-term not installed - use xterm with amber/green colours instead."
  # Only ed is allowed in the 1970s
  apt-get purge -y nano vim-tiny vim mousepad || true
fi

id "$AGENT" >/dev/null 2>&1 || useradd -m -s /bin/bash "$AGENT"
echo "$AGENT:tva" | chpasswd

# ---------- a bare 1970s shell: dash, "% " prompt, only a handful of commands ----------
rm -rf /opt/era1
mkdir -p /opt/era1/bin
for c in ls cat more ed date find sh clear pwd head grep; do
  p=$(type -P "$c" || true)
  [ -n "$p" ] && ln -s "$p" "/opt/era1/bin/$c"
done
# cc needs the assembler and linker on PATH, so it gets a small wrapper
printf '#!/bin/sh\nPATH=/usr/bin:/bin exec /usr/bin/gcc "$@"\n' > /opt/era1/bin/cc
chmod 755 /opt/era1/bin/cc
cat > /usr/local/bin/era1-shell <<'EOF'
#!/bin/sh
# Login shell for the 1970s station. Passes through non-interactive use (sh -c ...).
if [ "$#" -gt 0 ]; then exec /bin/sh "$@"; fi
cd "$HOME"
PATH=/opt/era1/bin PS1='% ' ENV= exec /bin/dash -i
EOF
chmod 755 /usr/local/bin/era1-shell
grep -qx /usr/local/bin/era1-shell /etc/shells || echo /usr/local/bin/era1-shell >> /etc/shells
chsh -s /usr/local/bin/era1-shell "$AGENT"

# ---------- CASEFILE ----------
cat > "$H/CASEFILE" <<'EOF'
=====================================================
  TIME VARIANCE AUTHORITY  -  CASE FILE 1971-1103
=====================================================
NEXUS EVENT: Bell Labs, the birth of Unix and C.

The variant has sabotaged three things:
  1. hello.c - the most famous first program in history.
     It no longer compiles. Compile it with:  cc hello.c
     then run it with:  ./a.out
  2. mail.sh - the first network email. Run it with:  sh mail.sh
  3. vault   - holds the code word. Run it with:  ./vault

The only editor in this decade is ed. Good luck, agent.
EOF

# ---------- Easy: hello.c with a missing semicolon ----------
cat > "$H/hello.c" <<'EOF'
#include <stdio.h>

/* hello.c - from "The C Programming Language" (Kernighan & Ritchie, 1978).
   The variant tampered with it, and now it no longer compiles. */

static const unsigned char clue[] = {
    0x69, 0x46, 0x5f, 0x4f, 0x10, 0x0a, 0x47, 0x4b, 0x43, 0x46, 0x04, 0x59, 0x42, 0x0a, 0x49, 0x4b,
    0x44, 0x44, 0x45, 0x5e, 0x0a, 0x4e, 0x4f, 0x46, 0x43, 0x5c, 0x4f, 0x58, 0x0a, 0x53, 0x45, 0x5f,
    0x58, 0x0a, 0x45, 0x58, 0x4e, 0x4f, 0x58, 0x59, 0x04, 0x0a, 0x66, 0x45, 0x45, 0x41, 0x0a, 0x49,
    0x46, 0x45, 0x59, 0x4f, 0x46, 0x53, 0x0a, 0x4b, 0x5e, 0x0a, 0x42, 0x45, 0x5d, 0x0a, 0x43, 0x5e,
    0x0a, 0x5d, 0x58, 0x43, 0x5e, 0x4f, 0x59, 0x0a, 0x5e, 0x42, 0x4f, 0x0a, 0x4b, 0x4e, 0x4e, 0x58,
    0x4f, 0x59, 0x59, 0x04
};

int main(void)
{
    printf("hello, world\n")
    for (int i = 0; i < (int)sizeof clue; i++)
        putchar(clue[i] ^ 0x2A);
    putchar('\n');
    return 0;
}
EOF

# ---------- Medium: mail.sh uses # instead of @ ----------
cat > "$H/mail.sh" <<'EOF'
#!/bin/sh
# mail.sh - network mail, BBN, 1971.
# Delivers your TVA orders to your mailbox.
PATH=/usr/bin:/bin

TO="agent#tva"

case "$TO" in
  *@*) ;;
  *) echo "mail: cannot route '$TO': an address needs a user and a host"; exit 1 ;;
esac
if [ "$TO" != "agent@tva" ]; then
  echo "mail: no such user or host: $TO"; exit 1
fi
echo "RnJvbSB0b21saW5zb25AYmJuLXRlbmV4YSAgTm92IDE5NzEKU3ViamVjdDogdGhlIG5leHVzIGRhdGUKCkFnZW50LAoKWW91IGp1c3QgcmVwYWlyZWQgdGhlIGZpcnN0IGV2ZXIgbmV0d29yayBlbWFpbCBhZGRyZXNzLiBXZWxsIGRvbmUuCgpUaGUgdmFyaWFudCBoaWQgdGhlIG5leHVzIHRpbWVzdGFtcCBpbiBhIGhpZGRlbiBmaWxlIGluIHlvdXIgaG9tZSBmb2xkZXIuClVuaXggY291bnRzIHRpbWUgYXMgc2Vjb25kcyBzaW5jZSAxIEphbnVhcnkgMTk3MC4KVHVybiB0aG9zZSBzZWNvbmRzIGludG8gYSBkYXRlLCB0aGVuIGdpdmUgdGhhdCBkYXRlIHRvIC4vdmF1bHQKCiAgLS0gVFZBCg==" | base64 -d > "$HOME/mbox"
echo "Delivered to $TO. Read your mail with:  cat mbox"
EOF

# ---------- Stretch: hidden epoch timestamp (3 Nov 1971, the first Unix manual) ----------
echo 58017600 > "$H/.nexus"

# ---------- vault: compiled, source removed ----------
TMP=$(mktemp -d)
cat > "$TMP/vault.c" <<'EOF'
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static const unsigned char w[] = { 0x65, 0x70, 0x7a, 0x74 };

int main(void)
{
    char in[128], out[64] = {0};
    int p[2];
    puts("=== TVA VAULT ===");
    printf("Enter the nexus date: ");
    fflush(stdout);
    if (!fgets(in, sizeof in, stdin)) return 1;
    in[strcspn(in, "\n")] = 0;
    if (pipe(p) != 0) return 1;
    pid_t pid = fork();
    if (pid == 0) {
        int dn = open("/dev/null", O_WRONLY);
        dup2(p[1], 1); dup2(dn, 2); close(p[0]);
        execl("/usr/bin/date", "date", "-u", "-d", in, "+%F", (char *)0);
        _exit(1);
    }
    close(p[1]);
    ssize_t n = read(p[0], out, sizeof out - 1);
    close(p[0]);
    waitpid(pid, 0, 0);
    if (n > 0) out[strcspn(out, "\n")] = 0;
    if (strcmp(out, "1971-11-03") != 0) {
        puts("ACCESS DENIED. That is not the nexus date.");
        return 1;
    }
    printf("Branch pruned. Code word: ");
    for (int i = 0; i < 4; i++) putchar(w[i] ^ out[i]);
    putchar('\n');
    return 0;
}
EOF
gcc -O2 -s -o "$H/vault" "$TMP/vault.c"
rm -rf "$TMP"

# ---------- autostart: CRT terminal + the TVA Analyst ----------
mkdir -p "$H/.config/autostart"
cat > "$H/.config/autostart/era.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=1970s Terminal
Exec=cool-retro-term --fullscreen --profile "Monochrome Green"
EOF
cat > "$H/.config/autostart/analyst.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=TVA Analyst
Exec=xfce4-terminal --title "TVA Analyst" -x /usr/local/bin/tva-analyst
EOF

chown -R "$AGENT:$AGENT" "$H"
chmod 755 "$H/vault"
chmod 644 "$H/hello.c" "$H/mail.sh" "$H/CASEFILE" "$H/.nexus"
echo
echo "Station 1 ready. Player account: $AGENT (password: tva)."
