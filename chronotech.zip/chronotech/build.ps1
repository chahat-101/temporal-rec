# Chronotech - builds ONE station VM directly into this Windows PC's VirtualBox.
#
#   Double-click build.bat              shows a menu to pick the station
#   build.bat -Station 3                builds station 3 without the menu
#   build.bat -Station 3 -Iso D:\debian-13.1.0-amd64-netinst.iso
#
# Needs: VirtualBox, Packer (winget install Hashicorp.Packer), the Debian 13 netinst ISO,
# and an internet connection while it builds.

param(
    [int]$Station = 0,
    [string]$Iso = ""
)

# Native tools (VBoxManage, packer) are checked through $LASTEXITCODE instead
$ErrorActionPreference = "Continue"
Set-Location -Path $PSScriptRoot

$stations = [ordered]@{
    1 = "1970s  Bell Labs: Unix, C and email      (code word TIME)"
    2 = "1980s  GNU, floppies, first PC virus     (code word LOOP)"
    3 = "1990s  The web goes public               (code word BYTE)"
    4 = "2000s  Y2K, Orkut and Bitcoin            (code word CORE)"
    5 = "2010s  GitHub and the cloud              (code word ZERO)"
    6 = "2020s  The Temporal Loom (finale)        - not ready yet"
}

function Stop-WithMessage([string]$msg) {
    Write-Host ""
    Write-Host $msg -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit 1
}

# ---------- pick the station ----------
if ($Station -eq 0) {
    Write-Host ""
    Write-Host "  CHRONOTECH - which station is this PC?" -ForegroundColor Cyan
    Write-Host ""
    foreach ($k in $stations.Keys) { Write-Host ("   {0}. {1}" -f $k, $stations[$k]) }
    Write-Host ""
    $answer = Read-Host "Type a number (1-6)"
    [int]::TryParse($answer, [ref]$Station) | Out-Null
}
if ($Station -lt 1 -or $Station -gt 6) { Stop-WithMessage "Please choose a station from 1 to 6." }
if ($Station -eq 6) { Stop-WithMessage "Station 6 is not built yet." }
$name = "station$Station"
$vmName = "chronotech-$name"
Write-Host "Building $name : $($stations[$Station])" -ForegroundColor Green

# ---------- check the tools ----------
$vbox = (Get-Command VBoxManage.exe -ErrorAction SilentlyContinue).Source
if (-not $vbox) {
    $vboxDir = if ($env:VBOX_MSI_INSTALL_PATH) { $env:VBOX_MSI_INSTALL_PATH } else { "C:\Program Files\Oracle\VirtualBox\" }
    $vbox = Join-Path $vboxDir "VBoxManage.exe"
}
if (-not (Test-Path $vbox)) { Stop-WithMessage "VirtualBox is not installed. Install it from virtualbox.org first." }
$vboxDir = Split-Path $vbox

if (-not (Get-Command packer.exe -ErrorAction SilentlyContinue)) {
    Stop-WithMessage "Packer is not installed. Run this, then open a new window and try again:`n  winget install Hashicorp.Packer"
}

$gaIso = Join-Path $vboxDir "VBoxGuestAdditions.iso"
if (-not (Test-Path $gaIso)) { Stop-WithMessage "Could not find $gaIso (it comes with VirtualBox)." }

# ---------- find the Debian ISO ----------
if (-not $Iso) {
    $found = Get-ChildItem -Path "$HOME\Downloads", $PSScriptRoot -Filter "debian-13*-amd64-netinst.iso" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { $Iso = $found.FullName }
}
if (-not $Iso -or -not (Test-Path $Iso)) {
    Stop-WithMessage "Could not find the Debian 13 netinst ISO. Put it in Downloads or in this folder, or run:`n  build.bat -Station $Station -Iso C:\path\to\debian-13.x.x-amd64-netinst.iso"
}
Write-Host "Using ISO: $Iso"
$isoArg = $Iso -replace '\\', '/'
$gaArg  = $gaIso -replace '\\', '/'

# ---------- an existing VM with the same name? ----------
& $vbox showvminfo $vmName *> $null
if ($LASTEXITCODE -eq 0) {
    $reply = Read-Host "A VM called $vmName already exists on this PC. Delete it and build a fresh one? (y/n)"
    if ($reply -ne "y") { Stop-WithMessage "Stopped. Nothing was changed." }
    & $vbox controlvm $vmName poweroff *> $null
    Start-Sleep -Seconds 2
    & $vbox unregistervm $vmName --delete
}

# ---------- admin password for the volunteers' account ----------
$sec = Read-Host "Choose an admin password for this VM (volunteers only)" -AsSecureString
$adminPassword = [System.Net.NetworkCredential]::new("", $sec).Password
if (-not $adminPassword) { Stop-WithMessage "The admin password cannot be empty." }

# Optional: a cache/ folder copied from a PC that already ran a build saves downloads
New-Item -ItemType Directory -Force -Path "cache" | Out-Null

# ---------- build ----------
Write-Host ""
Write-Host "Building. This takes roughly 20-40 minutes. Leave this window open." -ForegroundColor Cyan
Write-Host "If Windows Firewall asks about packer.exe, click Allow (the new VM downloads its setup answers from it)."
Write-Host ""

& packer init .
if ($LASTEXITCODE -ne 0) { Stop-WithMessage "packer init failed (is this PC online?)." }

& packer build -force "-only=virtualbox-iso.$name" `
    -var "iso_path=$isoArg" `
    -var "admin_password=$adminPassword" `
    -var "ga_iso=$gaArg" `
    -var "keep_registered=true" `
    -var "skip_export=true" .
if ($LASTEXITCODE -ne 0) { Stop-WithMessage "The build failed. Scroll up for the first red error and send it over." }

# ---------- clean snapshot to restore between teams ----------
& $vbox snapshot $vmName take clean --description "Restore this after every team"

Write-Host ""
Write-Host "Done. '$vmName' is in VirtualBox with a snapshot called 'clean'." -ForegroundColor Green
Write-Host "Do not delete the output\$name folder: the VM's disk lives there."
if ($Station -eq 5) {
    Write-Host "Players connect from this PC with:  ssh -p 2222 agent@localhost   (password tva)"
    Write-Host "Hints:                              ssh -p 2222 analyst@localhost (password analyst)"
}
Read-Host "Press Enter to close"
