#!/bin/bash
# Runs inside each VM during the Packer build (as root). Not for running by hand.
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
cd /tmp/ct

echo "==> [$STATION] VirtualBox Guest Additions"
if [ -f VBoxGuestAdditions.iso ]; then
  mkdir -p /mnt/ga
  mount -o loop,ro VBoxGuestAdditions.iso /mnt/ga
  sh /mnt/ga/VBoxLinuxAdditions.run --nox11 || true
  umount /mnt/ga
fi

echo "==> [$STATION] TVA Analyst"
bash analyst-setup.sh

echo "==> [$STATION] Station files"
bash "$STATION-setup.sh"

if [ -d /etc/lightdm ]; then
  echo "==> [$STATION] Auto-login as agent"
  mkdir -p /etc/lightdm/lightdm.conf.d
  printf '[Seat:*]\nautologin-user=agent\nautologin-user-timeout=0\n' > /etc/lightdm/lightdm.conf.d/50-chronotech.conf
fi

echo "==> [$STATION] Clean up"
cd /
rm -rf /tmp/ct
apt-get clean
# The build account keeps sudo for volunteers, with the admin password you chose
echo "builder:$ADMIN_PASSWORD" | chpasswd
