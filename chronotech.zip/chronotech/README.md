# Chronotech station builder

## On the Windows lab PCs (one station per PC)

1. Install VirtualBox, then Packer:  `winget install Hashicorp.Packer`
2. Put the Debian 13 netinst ISO in Downloads (or in this folder).
3. Double-click `build.bat`, type the station number for this PC, choose an
   admin password. Leave the window open for roughly 20-40 minutes.
4. The VM appears in VirtualBox with a snapshot called `clean`.
   Restore it after every team. Don't delete `output\stationN` - the disk lives there.

Without the menu:  `build.bat -Station 3`

Tip for slow internet: after one build on Arch, copy the `cache` folder into
this folder on each PC, and the VMs copy Ollama and the AI model from it
instead of downloading them.

## On Arch (builds .ova files to copy elsewhere)

## One-time setup (Arch)

    sudo pacman -S packer ollama

(Ollama on Arch is only used to download the AI model once; the build copies it
into every VM instead of downloading it five times.)

You also need VirtualBox (already installed) and the Debian 13 netinst ISO.

## Build

    ./build.sh                       # all five stations, one after another
    ./build.sh station3              # just one
    ISO=/path/to/debian.iso ./build.sh   # if the ISO is not in ~/Downloads

It asks for an admin password: that becomes the password of the `builder`
admin account inside every VM. Players use `agent` (password `tva`), which has
no admin rights.

The first run downloads Ollama and the AI model once (about 3-4 GB, into
`cache/`). After that each station takes roughly 15-25 minutes on a good
connection, almost all of it the Debian install. It runs unattended, so you can
leave it overnight. With 16 GB+ RAM, `JOBS=2 ./build.sh` builds two at a time.
The finished files land in `output/stationN/`.

## After the build, on each Windows lab PC

1. Double-click the station's .ova (or VirtualBox > File > Import Appliance).
2. Start it once, check it, shut it down.
3. Take a snapshot called `clean`. Restore it after every team.

Station 5 has no desktop. Players use Windows Terminal on the host PC:
`ssh -p 2222 agent@localhost`, and `ssh -p 2222 analyst@localhost` for hints.

## Files

- `chronotech.pkr.hcl`  - the VM definitions
- `preseed.pkrtpl.hcl`  - answers for the unattended Debian install
- `provision.sh`        - runs inside each VM during the build
- `files/`              - station scripts and the TVA Analyst
- `cache/`              - Ollama and the AI model, downloaded on the first run
- `ANSWER-KEY.md`       - volunteers only, never copy into a VM
