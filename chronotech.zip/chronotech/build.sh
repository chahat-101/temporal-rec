#!/bin/bash
# Chronotech - builds every station VM and exports each as an .ova.
#
#   ./build.sh                     build all five stations, one after another
#   ./build.sh station1 station4   build only those stations
#   JOBS=2 ./build.sh              build two at a time (needs 16 GB+ RAM on this PC)
#
# Needs: virtualbox, packer, and the Debian 13 netinst ISO.
set -euo pipefail
cd "$(dirname "$0")"

command -v packer >/dev/null || { echo "Install Packer first:  sudo pacman -S packer"; exit 1; }
command -v VBoxManage >/dev/null || { echo "VirtualBox is not installed."; exit 1; }

ISO=${ISO:-$(ls ~/Downloads/debian-13*-amd64-netinst.iso 2>/dev/null | head -1 || true)}
if [ -z "$ISO" ] || [ ! -f "$ISO" ]; then
  echo "Could not find the Debian ISO. Run again with its path, for example:"
  echo "  ISO=~/Downloads/debian-13.1.0-amd64-netinst.iso ./build.sh"
  exit 1
fi
echo "Using ISO: $ISO"

if [ -z "${ADMIN_PASSWORD:-}" ]; then
  read -rsp "Choose an admin password for the finished VMs (for volunteers only): " ADMIN_PASSWORD; echo
fi
[ -n "$ADMIN_PASSWORD" ] || { echo "The admin password cannot be empty."; exit 1; }

# ---------- download the big pieces once, instead of once per VM ----------
CACHE=cache
mkdir -p "$CACHE"
if ! ls "$CACHE"/ollama-linux-amd64.* >/dev/null 2>&1; then
  echo "==> Downloading Ollama once for all VMs"
  curl -fL -o "$CACHE/ollama-linux-amd64.tar.zst" https://ollama.com/download/ollama-linux-amd64.tar.zst \
    || { rm -f "$CACHE/ollama-linux-amd64.tar.zst"
         curl -fL -o "$CACHE/ollama-linux-amd64.tgz" https://ollama.com/download/ollama-linux-amd64.tgz; }
fi
if [ ! -d "$CACHE/models/manifests" ]; then
  command -v ollama >/dev/null || { echo "To download the AI model only once, install Ollama here first:  sudo pacman -S ollama"; exit 1; }
  echo "==> Downloading the AI model once for all VMs"
  OLLAMA_MODELS="$PWD/$CACHE/models" OLLAMA_HOST=127.0.0.1:11999 ollama serve >/dev/null 2>&1 &
  SRV=$!
  sleep 4
  OLLAMA_HOST=127.0.0.1:11999 ollama pull llama3.2:3b
  kill "$SRV"
fi

ONLY=()
if [ $# -gt 0 ]; then
  list=$(printf 'virtualbox-iso.%s,' "$@"); ONLY=("-only=${list%,}")
fi

packer init .
packer build -parallel-builds="${JOBS:-1}" -force "${ONLY[@]}" \
  -var "iso_path=$ISO" -var "admin_password=$ADMIN_PASSWORD" .

echo
echo "Done. Your VMs:"
ls -lh output/*/*.ova
