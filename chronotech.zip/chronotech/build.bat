@echo off
rem Chronotech - double-click to build this PC's station VM.
rem Runs build.ps1 for this window only, without changing the PC's PowerShell settings.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1" %*
